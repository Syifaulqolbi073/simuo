<?php

use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\AcademicYearController;

Route::middleware(['auth'])->group(function () {

    Route::view('/dashboard', 'admin.dashboard.index')
        ->name('dashboard');

    Route::resource('academic-years', AcademicYearController::class);
    Route::patch(
    'academic-years/{academicYear}/activate',
    [AcademicYearController::class, 'activate']
)->name('academic-years.activate');

});

Route::middleware(['auth'])->group(function () {

    Route::view('/dashboard', 'admin.dashboard.index')
        ->name('dashboard');

});
Route::get('/', function () {
    return view('welcome');
});


Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
