<?php $__env->startSection('content'); ?>

<div class="max-w-3xl mx-auto">

    <h1 class="text-2xl font-bold mb-6">
        Tambah Tahun Pelajaran
    </h1>

    <div class="bg-white rounded-xl shadow p-6">

        <form
            action="<?php echo e(route('academic-years.store')); ?>"
            method="POST">

            <?php echo $__env->make('admin.academic-years.partials.form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        </form>

    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/Projects/simuo/resources/views/admin/academic-years/create.blade.php ENDPATH**/ ?>