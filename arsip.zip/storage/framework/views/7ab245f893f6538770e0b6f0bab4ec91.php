<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('app.name', 'SIMUO')); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
</head>

<body class="bg-slate-100">

<div class="flex min-h-screen">

    
    <?php if (isset($component)) { $__componentOriginalba84f018f829d038037e843bd5075a8a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalba84f018f829d038037e843bd5075a8a = $attributes; } ?>
<?php $component = App\View\Components\Layout\Sidebar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.sidebar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout\Sidebar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalba84f018f829d038037e843bd5075a8a)): ?>
<?php $attributes = $__attributesOriginalba84f018f829d038037e843bd5075a8a; ?>
<?php unset($__attributesOriginalba84f018f829d038037e843bd5075a8a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalba84f018f829d038037e843bd5075a8a)): ?>
<?php $component = $__componentOriginalba84f018f829d038037e843bd5075a8a; ?>
<?php unset($__componentOriginalba84f018f829d038037e843bd5075a8a); ?>
<?php endif; ?>

    
    <div class="flex-1">

        <?php if (isset($component)) { $__componentOriginal1123ab115b514343a1dfb86d9c409788 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1123ab115b514343a1dfb86d9c409788 = $attributes; } ?>
<?php $component = App\View\Components\Layout\Navbar::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Layout\Navbar::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1123ab115b514343a1dfb86d9c409788)): ?>
<?php $attributes = $__attributesOriginal1123ab115b514343a1dfb86d9c409788; ?>
<?php unset($__attributesOriginal1123ab115b514343a1dfb86d9c409788); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1123ab115b514343a1dfb86d9c409788)): ?>
<?php $component = $__componentOriginal1123ab115b514343a1dfb86d9c409788; ?>
<?php unset($__componentOriginal1123ab115b514343a1dfb86d9c409788); ?>
<?php endif; ?>

        <main class="p-6">

            <?php echo $__env->yieldContent('content'); ?>

        </main>

    </div>

</div>

</body>
</html><?php /**PATH /data/data/com.termux/files/home/Projects/simuo/resources/views/layouts/app.blade.php ENDPATH**/ ?>