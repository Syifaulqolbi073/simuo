<?php $__env->startSection('title','Tahun Pelajaran'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-7xl mx-auto">

    <div class="flex items-center justify-between mb-6">
        <div>
            <h1 class="text-2xl font-bold">Tahun Pelajaran</h1>
            <p class="text-gray-500">Daftar Tahun Pelajaran</p>
        </div>

        <a href="<?php echo e(route('academic-years.create')); ?>"
           class="bg-green-700 hover:bg-green-800 text-white px-4 py-2 rounded-lg">
            + Tambah
        </a>
    </div>
<form method="GET" action="<?php echo e(route('academic-years.index')); ?>" class="mb-4">
    <div class="flex gap-2">
        <input
            type="text"
            name="search"
            value="<?php echo e(request('search')); ?>"
            placeholder="Cari kode atau nama..."
            class="w-full rounded-lg border-gray-300">

        <button
            type="submit"
            class="bg-blue-600 text-white px-4 rounded-lg">
            Cari
        </button>
    </div>
</form>
    <?php if(session('success')): ?>
        <div class="mb-4 rounded-lg bg-green-100 border border-green-300 text-green-800 px-4 py-3">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="bg-white rounded-xl shadow">

        <table class="min-w-full">

            <thead class="bg-slate-100">

                <tr>

                    <th class="px-4 py-3 text-left">Kode</th>

                    <th class="px-4 py-3 text-left">Nama</th>

                    <th class="px-4 py-3 text-left">Mulai</th>

                    <th class="px-4 py-3 text-left">Selesai</th>

                    <th class="px-4 py-3 text-center">Status</th>

                    <th class="px-4 py-3 text-center">Aksi</th>

                </tr>

            </thead>

            <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $academicYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $academicYear): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <tr class="border-t">

                    <td class="px-4 py-3"><?php echo e($academicYear->code); ?></td>

                    <td class="px-4 py-3"><?php echo e($academicYear->name); ?></td>

                    <td class="px-4 py-3"><?php echo e($academicYear->start_date->format('d-m-Y')); ?></td>

                    <td class="px-4 py-3"><?php echo e($academicYear->end_date->format('d-m-Y')); ?></td>

                    <td class="px-4 py-3 text-center">

                        <?php if($academicYear->is_active): ?>
                            <span class="px-2 py-1 rounded bg-green-100 text-green-700 text-sm">
                                Aktif
                            </span>
                        <?php else: ?>
                            <span class="px-2 py-1 rounded bg-gray-100 text-gray-700 text-sm">
                                Nonaktif
                            </span>
                        <?php endif; ?>

                    </td>
<td class="px-4 py-3 text-center">

    <div class="flex justify-center gap-3">

        <?php if(!$academicYear->is_active): ?>

            <form
                action="<?php echo e(route('academic-years.activate',$academicYear)); ?>"
                method="POST">

                <?php echo csrf_field(); ?>
                <?php echo method_field('PATCH'); ?>

                <button
                    class="text-green-600 hover:underline">

                    Aktifkan

                </button>

            </form>

        <?php endif; ?>

        <a
            href="<?php echo e(route('academic-years.edit',$academicYear)); ?>"
            class="text-blue-600 hover:underline">

            Edit

        </a>

        <form
            action="<?php echo e(route('academic-years.destroy',$academicYear)); ?>"
            method="POST"
            onsubmit="return confirm('Yakin ingin menghapus data ini?')">

            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>

            <button
                class="text-red-600 hover:underline">

                Hapus

            </button>

        </form>

    </div>

</td>


                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <tr>

                    <td colspan="6" class="text-center py-8 text-gray-500">
                        Belum ada data Tahun Pelajaran.
                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

    <div class="mt-5">

        <?php echo e($academicYears->links()); ?>


    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /data/data/com.termux/files/home/Projects/simuo/resources/views/admin/academic-years/index.blade.php ENDPATH**/ ?>